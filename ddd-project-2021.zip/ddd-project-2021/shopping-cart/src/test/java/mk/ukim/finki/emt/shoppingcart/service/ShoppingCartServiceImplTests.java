package mk.ukim.finki.emt.shoppingcart.service;
import mk.ukim.finki.emt.sharedkernel.domain.financial.Money;
import mk.ukim.finki.emt.shoppingcart.domain.valueobjects.Product;
import mk.ukim.finki.emt.shoppingcart.domain.valueobjects.ProductId;
import mk.ukim.finki.emt.shoppingcart.service.forms.ShoppingCartItemForm;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import java.util.Arrays;
import java.util.List;
@SpringBootTest
public class ShoppingCartServiceImplTests {

    @Autowired
    private ShoppingCartService shoppingCartService;

    private static Product newProduct(String name, Money price) {
        Product p = new Product(ProductId.randomId(ProductId.class), name, price);
        return p;
    }

}