package mk.ukim.finki.emt.shoppingcart.service;

import mk.ukim.finki.emt.shoppingcart.domain.exceptions.ShoppingCartIdNotExistsException;
import mk.ukim.finki.emt.shoppingcart.domain.models.ShoppingCart;
import mk.ukim.finki.emt.shoppingcart.domain.models.ShoppingCartId;
import mk.ukim.finki.emt.shoppingcart.domain.models.ShoppingCartItemId;
import mk.ukim.finki.emt.shoppingcart.service.forms.ShoppingCartForm;
import mk.ukim.finki.emt.shoppingcart.service.forms.ShoppingCartItemForm;

import java.util.List;
import java.util.Optional;

public interface ShoppingCartService {
    ShoppingCartId addProduct(ShoppingCartForm shoppingCartForm);
    List<ShoppingCart> findAll();
    Optional<ShoppingCart> findById(ShoppingCartId id);

    void addItem(ShoppingCartId shoppingCartId, ShoppingCartItemForm shoppingCartItemForm) throws ShoppingCartIdNotExistsException;
    void deleteItem(ShoppingCartId shoppingCartId, ShoppingCartItemId shoppingCartItemId) throws ShoppingCartIdNotExistsException, ShoppingCartIdNotExistsException;

}
