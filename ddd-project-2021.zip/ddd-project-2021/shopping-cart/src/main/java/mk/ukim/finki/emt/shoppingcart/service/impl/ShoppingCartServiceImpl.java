package mk.ukim.finki.emt.shoppingcart.service.impl;


import lombok.AllArgsConstructor;
import mk.ukim.finki.emt.shoppingcart.domain.exceptions.ShoppingCartIdNotExistsException;
import mk.ukim.finki.emt.shoppingcart.domain.models.ShoppingCart;
import mk.ukim.finki.emt.shoppingcart.domain.models.ShoppingCartId;
import mk.ukim.finki.emt.shoppingcart.domain.models.ShoppingCartItemId;
import mk.ukim.finki.emt.shoppingcart.domain.repository.ShoppingCartRepository;
import mk.ukim.finki.emt.shoppingcart.service.ShoppingCartService;
import mk.ukim.finki.emt.shoppingcart.service.forms.ShoppingCartForm;
import mk.ukim.finki.emt.shoppingcart.service.forms.ShoppingCartItemForm;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;


import javax.validation.ConstraintViolationException;
import javax.validation.Validator;
import java.time.Instant;
import java.util.List;
import java.util.Objects;
import java.util.Optional;

@Service
@Transactional
@AllArgsConstructor
public class ShoppingCartServiceImpl implements ShoppingCartService {

    private final ShoppingCartRepository shoppingCartRepository;
    private final Validator validator;

    @Override
    public ShoppingCartId addProduct(ShoppingCartForm shoppingCartForm) {
        Objects.requireNonNull(shoppingCartForm, "shopping cart must not be null");
        var constraintViolations = validator.validate(shoppingCartForm);

        if (constraintViolations.size() > 0) {
            throw new ConstraintViolationException("The shopping cart  form is not valid", constraintViolations);
        }
        var newShoppingCart = shoppingCartRepository.saveAndFlush(toDomainObject(shoppingCartForm));
        return newShoppingCart.getId();
    }

    @Override
    public List<ShoppingCart> findAll() {
        return shoppingCartRepository.findAll();
    }

    @Override
    public Optional<ShoppingCart> findById(ShoppingCartId id) {
        return shoppingCartRepository.findById(id);
    }

    @Override
    public void addItem(ShoppingCartId shoppingCartId, ShoppingCartItemForm shoppingCartItemForm) throws ShoppingCartIdNotExistsException {
        ShoppingCart shoppingCart = shoppingCartRepository.findById(shoppingCartId).orElseThrow(ShoppingCartIdNotExistsException::new);
                shoppingCart.addItem(shoppingCartItemForm.getProduct(),shoppingCartItemForm.getQuantity());
                shoppingCartRepository.saveAndFlush(shoppingCart);
    }

    @Override
    public void deleteItem(ShoppingCartId shoppingCartId, ShoppingCartItemId shoppingCartItemId) throws ShoppingCartIdNotExistsException, ShoppingCartIdNotExistsException {
       ShoppingCart shoppingCart = shoppingCartRepository.findById(shoppingCartId).orElseThrow(ShoppingCartIdNotExistsException::new);
      shoppingCart.removeItem(shoppingCartItemId);
      shoppingCartRepository.saveAndFlush(shoppingCart);
    }

    private ShoppingCart toDomainObject(ShoppingCartForm shoppingCartForm) {
        var shoppingCart = new ShoppingCart(Instant.now(), shoppingCartForm.getCurrency());
        shoppingCartForm.getItems().forEach(item->shoppingCart.addItem(item.getProduct(),item.getQuantity()));
        return shoppingCart;
    }

}
