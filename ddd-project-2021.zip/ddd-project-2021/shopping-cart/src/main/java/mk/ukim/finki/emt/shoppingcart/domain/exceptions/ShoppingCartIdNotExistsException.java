package mk.ukim.finki.emt.shoppingcart.domain.exceptions;

public class ShoppingCartIdNotExistsException extends RuntimeException{
}
