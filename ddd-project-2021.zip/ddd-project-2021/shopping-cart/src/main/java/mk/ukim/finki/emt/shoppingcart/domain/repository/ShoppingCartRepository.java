package mk.ukim.finki.emt.shoppingcart.domain.repository;

import mk.ukim.finki.emt.shoppingcart.domain.models.ShoppingCart;
import mk.ukim.finki.emt.shoppingcart.domain.models.ShoppingCartId;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ShoppingCartRepository extends JpaRepository<ShoppingCart, ShoppingCartId> {
}
