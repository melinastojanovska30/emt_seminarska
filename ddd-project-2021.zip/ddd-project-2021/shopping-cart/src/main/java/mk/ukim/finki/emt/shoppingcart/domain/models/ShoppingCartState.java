package mk.ukim.finki.emt.shoppingcart.domain.models;

public enum ShoppingCartState {
    RECEVIED, PROCESSING, CANCELLED, PROCESSED
}
