package mk.ukim.finki.emt.shoppingcart.domain.models;

import mk.ukim.finki.emt.sharedkernel.domain.base.DomainObjectId;

public class ShoppingCartItemId extends DomainObjectId {
    private ShoppingCartItemId() {
        super(ShoppingCartItemId.randomId(ShoppingCartItemId.class).getId());
    }

    public ShoppingCartItemId(String uuid) {
        super(uuid);
    }

}
