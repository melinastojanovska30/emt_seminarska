package mk.ukim.finki.emt.shoppingcart.service.forms;


import lombok.Data;
import mk.ukim.finki.emt.shoppingcart.domain.valueobjects.Product;

import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;

@Data
public class ShoppingCartItemForm {
    @NotNull
    private Product product;

    @Min(1)
    private int quantity = 1;

}
