package mk.ukim.finki.emt.shoppingcart.domain.models;


import lombok.NonNull;

import mk.ukim.finki.emt.sharedkernel.domain.base.AbstractEntity;
import mk.ukim.finki.emt.sharedkernel.domain.financial.Currency;
import mk.ukim.finki.emt.sharedkernel.domain.financial.Money;
import mk.ukim.finki.emt.shoppingcart.domain.valueobjects.Product;

import javax.persistence.*;
import javax.validation.constraints.NotNull;
import java.time.Instant;
import java.util.Objects;
import java.util.Set;

@Entity
@Table(name="shopping_cart")
public class ShoppingCart extends AbstractEntity<ShoppingCartId> {
    private Instant addedOn;
    @Enumerated(EnumType.STRING)
    private ShoppingCartState shoppingCartState;

    @Column(name = "shopping_cart_currency")
    @Enumerated(EnumType.STRING)
    private Currency currency;


    @OneToMany(cascade = CascadeType.ALL, orphanRemoval = true, fetch = FetchType.EAGER)
    private Set<ShoppingCartItem> shoppingCartItemList;


    public ShoppingCart() {

        super(ShoppingCartId.randomId(ShoppingCartId.class));

    }

    public ShoppingCart(Instant now, mk.ukim.finki.emt.sharedkernel.domain.financial.Currency currency) {
        super(ShoppingCartId.randomId(ShoppingCartId.class));
        this.addedOn = now;
        this.currency = currency;
    }

    public Money total() {
        return shoppingCartItemList.stream().map(ShoppingCartItem::subtotal).reduce(new Money(currency, 0), Money::add);
    }


    public ShoppingCartItem addItem(@NonNull Product product, int qty) {
        Objects.requireNonNull(product, "product must not be null");
        var item = new ShoppingCartItem(product.getId(), product.getPrice(), qty);
        shoppingCartItemList.add(item);
        return item;
    }


    public void removeItem(@NonNull ShoppingCartItemId shoppingCartItemId) {
        Objects.requireNonNull(shoppingCartItemId, "Shopping cart item must not be null");
        shoppingCartItemList.removeIf(v -> v.getId().equals(shoppingCartItemId));

    }

}