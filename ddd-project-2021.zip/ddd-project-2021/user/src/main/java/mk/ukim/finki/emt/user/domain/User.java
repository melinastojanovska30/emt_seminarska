package mk.ukim.finki.emt.user.domain;

import mk.ukim.finki.emt.user.domain.valueobjects.UserId;

import javax.persistence.AttributeOverride;
import javax.persistence.AttributeOverrides;
