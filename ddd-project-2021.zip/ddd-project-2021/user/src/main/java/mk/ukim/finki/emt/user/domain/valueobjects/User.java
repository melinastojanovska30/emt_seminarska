package mk.ukim.finki.emt.user.domain.valueobjects;

import lombok.Getter;

@Getter
public class User {

}
