package mk.ukim.finki.emt.productcatalog.domain.exceptions;

public class ProductNotFoundException extends RuntimeException{

}
