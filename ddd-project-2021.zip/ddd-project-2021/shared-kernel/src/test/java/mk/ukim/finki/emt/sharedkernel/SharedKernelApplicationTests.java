package mk.ukim.finki.emt.sharedkernel;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SharedKernelApplicationTests {

    @Test
    void contextLoads() {
    }

}
